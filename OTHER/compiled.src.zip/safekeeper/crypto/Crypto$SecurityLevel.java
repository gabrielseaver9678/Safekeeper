package safekeeper.crypto;

public enum SecurityLevel {
  EXTREMELY_UNSECURE(1.728E14D),
  UNSECURE(1.5768E17D),
  SECURE(9.4608E18D),
  VERY_SECURE(Double.POSITIVE_INFINITY);
  
  private final double numCombos;
  
  SecurityLevel(double paramDouble) {
    this.numCombos = paramDouble;
  }
  
  public static SecurityLevel getSecurityLevel(double paramDouble) {
    if (paramDouble <= EXTREMELY_UNSECURE.numCombos)
      return EXTREMELY_UNSECURE; 
    if (paramDouble <= UNSECURE.numCombos)
      return UNSECURE; 
    if (paramDouble <= SECURE.numCombos)
      return SECURE; 
    return VERY_SECURE;
  }
}
