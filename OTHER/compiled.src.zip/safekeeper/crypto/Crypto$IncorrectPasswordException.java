package safekeeper.crypto;

public class IncorrectPasswordException extends Exception {
  public IncorrectPasswordException(String paramString) {
    super(paramString);
  }
}
