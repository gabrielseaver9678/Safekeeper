package safekeeper.crypto;

public class AlgorithmException extends Exception {
  public AlgorithmException(String paramString) {
    super(paramString);
  }
}
