package safekeeper.groupings;

public interface StringFromObject {
  String getString(Object paramObject);
}
