package safekeeper.groupings;

public class CorruptedSerializationException extends Exception {
  public CorruptedSerializationException(String paramString) {
    super(paramString);
  }
}
