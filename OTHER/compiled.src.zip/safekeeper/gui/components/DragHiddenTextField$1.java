package safekeeper.gui.components;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

class null extends MouseAdapter {
  public void mousePressed(MouseEvent paramMouseEvent) {
    DragHiddenTextField.this.setText(password);
    DragHiddenTextField.this.selectAll();
    DragHiddenTextField.this.getTransferHandler().exportAsDrag(DragHiddenTextField.this, paramMouseEvent, 1);
  }
}
