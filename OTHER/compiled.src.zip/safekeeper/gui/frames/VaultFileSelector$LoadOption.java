package safekeeper.gui.frames;

public enum LoadOption {
  CREATE_NEW, LOAD_EXISTING, NONE;
}
