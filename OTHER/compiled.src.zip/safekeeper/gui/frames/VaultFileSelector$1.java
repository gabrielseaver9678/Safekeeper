package safekeeper.gui.frames;

import java.awt.Color;
import safekeeper.gui.components.PasswordField;

class null implements Runnable {
  public void run() {
    boolean bool = VaultFileSelector.checkMasterPasswordValid(passwordField.getPassword(), false);
    Color color = bool ? Color.WHITE : VaultFileSelector.INVALID_MASTER_PASSWORD_COLOR;
    passwordField.setFieldBackground(color);
    passwordReentryField.setFieldBackground(color);
  }
}
