package safekeeper.gui.frames;

import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

class null implements DocumentListener {
  public void insertUpdate(DocumentEvent paramDocumentEvent) {
    updatePasswordFieldBackground.run();
  }
  
  public void removeUpdate(DocumentEvent paramDocumentEvent) {
    updatePasswordFieldBackground.run();
  }
  
  public void changedUpdate(DocumentEvent paramDocumentEvent) {}
}
