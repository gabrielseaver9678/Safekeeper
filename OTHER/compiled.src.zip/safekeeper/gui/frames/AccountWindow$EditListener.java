package safekeeper.gui.frames;

@FunctionalInterface
interface EditListener {
  void onFieldEdit();
}
