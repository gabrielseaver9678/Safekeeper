package safekeeper.gui.frames;

import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeWillExpandListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.ExpandVetoException;

class null implements TreeWillExpandListener {
  public void treeWillExpand(TreeExpansionEvent paramTreeExpansionEvent) throws ExpandVetoException {
    DefaultMutableTreeNode defaultMutableTreeNode = (DefaultMutableTreeNode)paramTreeExpansionEvent.getPath().getLastPathComponent();
    if (defaultMutableTreeNode instanceof MainWindow.ServiceTreeAccountNode) {
      ((MainWindow.ServiceTreeAccountNode)defaultMutableTreeNode).displayAccountWindow();
      throw new ExpandVetoException(paramTreeExpansionEvent, "Account node expansion veto");
    } 
  }
  
  public void treeWillCollapse(TreeExpansionEvent paramTreeExpansionEvent) throws ExpandVetoException {
    if (((DefaultMutableTreeNode)paramTreeExpansionEvent.getPath().getLastPathComponent()).isRoot())
      throw new ExpandVetoException(paramTreeExpansionEvent, "Root node cannot collapse"); 
  }
}
