package safekeeper.gui.frames;

import javax.swing.tree.DefaultMutableTreeNode;
import safekeeper.groupings.AccountGroup;
import safekeeper.groupings.ServiceGroup;

class ServiceTreeServiceNode extends DefaultMutableTreeNode {
  private ServiceTreeServiceNode(ServiceGroup paramServiceGroup) {
    super(paramServiceGroup.name);
    Object[] arrayOfObject = paramServiceGroup.getAccountsAlphabetical();
    for (Object object : arrayOfObject)
      add(new MainWindow.ServiceTreeAccountNode(paramMainWindow, (AccountGroup)object)); 
    if (paramServiceGroup.accountGroups.size() == 0)
      setAllowsChildren(false); 
  }
}
