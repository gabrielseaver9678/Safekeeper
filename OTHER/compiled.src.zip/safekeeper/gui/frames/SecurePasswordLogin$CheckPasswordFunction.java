package safekeeper.gui.frames;

@FunctionalInterface
public interface CheckPasswordFunction {
  boolean checkCorrectPassword(String paramString);
}
