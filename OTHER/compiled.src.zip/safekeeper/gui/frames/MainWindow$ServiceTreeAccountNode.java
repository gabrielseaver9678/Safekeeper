package safekeeper.gui.frames;

import javax.swing.tree.DefaultMutableTreeNode;
import safekeeper.groupings.AccountGroup;

class ServiceTreeAccountNode extends DefaultMutableTreeNode {
  private AccountGroup account;
  
  private ServiceTreeAccountNode(AccountGroup paramAccountGroup) {
    super(paramAccountGroup.username);
    this.account = paramAccountGroup;
  }
  
  private void displayAccountWindow() {
    if (MainWindow.this.accountWindow == null)
      new DisplayAccountWindow(MainWindow.this, this.account); 
  }
}
