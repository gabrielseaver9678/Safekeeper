package safekeeper.gui.frames;

import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

class null implements DocumentListener {
  public void insertUpdate(DocumentEvent paramDocumentEvent) {
    listener.onFieldEdit();
  }
  
  public void removeUpdate(DocumentEvent paramDocumentEvent) {
    listener.onFieldEdit();
  }
  
  public void changedUpdate(DocumentEvent paramDocumentEvent) {}
}
