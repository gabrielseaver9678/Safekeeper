package safekeeper.gui.frames;

public interface SaveFunction {
  boolean save();
}
