package safekeeper.gui.frames;

class ObjectHolder<T> {
  private T object;
  
  private ObjectHolder(T paramT) {
    this.object = paramT;
  }
}
