package safekeeper.gui.frames;

import javax.swing.tree.DefaultMutableTreeNode;
import safekeeper.groupings.ServiceGroup;
import safekeeper.groupings.ServiceGroupList;

class ServiceTreeRootNode extends DefaultMutableTreeNode {
  private ServiceTreeRootNode(ServiceGroupList paramServiceGroupList) {
    super("Services");
    Object[] arrayOfObject = paramServiceGroupList.getServicesAlphabetical();
    for (Object object : arrayOfObject)
      add(new MainWindow.ServiceTreeServiceNode(paramMainWindow, (ServiceGroup)object)); 
    if (paramServiceGroupList.serviceGroups.size() == 0)
      setAllowsChildren(false); 
  }
}
