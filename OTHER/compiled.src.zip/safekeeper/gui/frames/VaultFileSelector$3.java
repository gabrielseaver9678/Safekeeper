package safekeeper.gui.frames;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.concurrent.CountDownLatch;
import javax.swing.JFrame;
import safekeeper.gui.components.PasswordField;
import safekeeper.gui.util.GUIUtils;

class null implements ActionListener {
  public void actionPerformed(ActionEvent paramActionEvent) {
    if (passwordField.getPassword().isEmpty() || 
      !VaultFileSelector.checkMasterPasswordValid(passwordField.getPassword(), true))
      return; 
    if (passwordReentryField.getPassword().isEmpty()) {
      GUIUtils.showWarning("You must re-enter the master password into the re-entry field.");
      return;
    } 
    if (!passwordField.getPassword().equals(passwordReentryField.getPassword())) {
      GUIUtils.showWarning("The master password and the re-entered password do not match.");
      return;
    } 
    int i = GUIUtils.showOptionChooser(parentFrame, "Are you sure you want this to be your master password,\nwhich will be used to access this Safekeeper password\nvault in the future?", "Confirm Master Password", new String[] { "Confirm", "Cancel" }, 0);
    if (i != 0)
      return; 
    password.object = (T)passwordField.getPassword();
    latch.countDown();
  }
}
