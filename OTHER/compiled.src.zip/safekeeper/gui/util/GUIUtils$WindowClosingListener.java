package safekeeper.gui.util;

@FunctionalInterface
public interface WindowClosingListener {
  void onWindowClosing();
}
