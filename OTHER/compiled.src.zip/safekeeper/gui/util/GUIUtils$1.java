package safekeeper.gui.util;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

class null extends WindowAdapter {
  public void windowClosing(WindowEvent paramWindowEvent) {
    closingListener.onWindowClosing();
  }
}
